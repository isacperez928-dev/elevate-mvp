
let completed = 0;
let habits = {
  water: 0,
  workout: 0
};

function addTask() {
  const input = document.getElementById("taskInput");
  const taskText = input.value.trim();

  if (taskText === "") return;

  const li = document.createElement("li");
  li.innerHTML = `
    ${taskText}
    <button onclick="completeTask(this)">Done</button>
  `;

  document.getElementById("taskList").appendChild(li);
  input.value = "";
}

function completeTask(button) {
  button.parentElement.remove();
  completed++;
  document.getElementById("completedTasks").innerText = completed;
}

function increaseHabit(type) {
  habits[type]++;
  document.getElementById(type + "Count").innerText =
    habits[type] + " days";

  document.getElementById("habitTotal").innerText =
    habits.water + habits.workout;
}

document.getElementById("startBtn").addEventListener("click", () => {
  alert("Welcome to Elevate MVP!");
});
