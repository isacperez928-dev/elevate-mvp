
ELEVATE MVP WEBSITE

HOW TO RUN:
1. Download the ZIP file.
2. Extract it.
3. Open index.html in your browser.

FEATURES:
- Daily planner
- Habit tracker
- Progress tracker

NEXT STEPS:
- Add login/signup
- Connect database
- Deploy with Netlify or Vercel
- Convert into React app
